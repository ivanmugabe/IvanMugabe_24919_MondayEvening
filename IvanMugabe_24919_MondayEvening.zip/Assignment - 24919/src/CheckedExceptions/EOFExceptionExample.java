package CheckedExceptions;

import java.io.*;
public class EOFExceptionExample {
    public static void main(String[] args) {
        try {
            FileInputStream file = new FileInputStream("example.txt");
            ObjectInputStream input = new ObjectInputStream(file);
            while (true) {
                System.out.println(input.readObject());
            }
        } catch (EOFException e) {
            System.out.println("Reached end of file: " + e.getMessage());
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
