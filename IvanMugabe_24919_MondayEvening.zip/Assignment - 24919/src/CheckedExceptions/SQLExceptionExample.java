package CheckedExceptions;

import java.sql.*;
public class SQLExceptionExample {
    public static void main(String[] args) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/nonexistent_db", "user", "password");
        } catch (SQLException e) {
            System.out.println("A database error occurred: " + e.getMessage());
        }
    }
}

