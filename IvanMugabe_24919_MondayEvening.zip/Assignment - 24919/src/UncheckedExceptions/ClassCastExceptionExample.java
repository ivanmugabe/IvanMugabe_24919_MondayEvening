package UncheckedExceptions;

public class ClassCastExceptionExample {
    public static void main(String[] args) {
        try {
            Object obj = "Hello"; // Object of type String
            Integer number = (Integer) obj; // Invalid cast triggers ClassCastException
        } catch (ClassCastException e) {
            System.out.println("A ClassCastException occurred: " + e.getMessage());
        }
    }
}
