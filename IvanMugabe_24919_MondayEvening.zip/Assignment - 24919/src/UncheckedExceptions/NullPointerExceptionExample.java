package UncheckedExceptions;

public class NullPointerExceptionExample {
    public static void main(String[] args) {
        try {
            String str = null; // Null reference
            System.out.println(str.length()); // Accessing length of null triggers NullPointerException
        } catch (NullPointerException e) {
            System.out.println("A NullPointerException occurred: " + e.getMessage());
        }
    }
}

